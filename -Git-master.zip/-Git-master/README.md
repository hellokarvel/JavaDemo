# -Git
零基础使用Git的读书笔记 可以选择`GitLearning.docx`文件下载docx版本的读书笔记，读书笔记中有重点彩色标记，也可以在线查看[GitLearning.md](GitLearning.md)

欢迎issue or pull requests~